﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SnakeController : MonoBehaviour {

    // Settings
    public float snakeMoveSpeed = 5;
    public float snakeRotationSpeed = 180;
    public float snakeBodySpeed = 5;
    public int bodyGap = 10;

    public float spawnRadius = 15f;

    // References
    public GameObject BodyPrefab;

    public GameObject foodPrefab;



    // Lists
    private List<GameObject> BodyParts = new List<GameObject>();
    private List<Vector3> PositionsHistory = new List<Vector3>();

    // Start is called before the first frame update
    void Start() {
        //create 1 body first
       
    }

    // Update is called once per frame
    void Update() {

        // Move forward
        transform.position += transform.forward * snakeMoveSpeed * Time.deltaTime;

        // Steer
        float snakeDirection = Input.GetAxis("Horizontal"); // Returns value -1, 0, or 1
        transform.Rotate(Vector3.up * snakeDirection * snakeRotationSpeed * Time.deltaTime);

        // Store position history
        PositionsHistory.Insert(0, transform.position);

        // Move body parts
        int index = 0;
        foreach (var body in BodyParts) {
            Vector3 point = PositionsHistory[Mathf.Clamp(index * bodyGap, 0, PositionsHistory.Count - 1)];

            // Move body towards the point along the snakes path
            Vector3 moveDirection = point - body.transform.position;
            body.transform.position += moveDirection * snakeBodySpeed * Time.deltaTime;

            // Rotate body towards the point along the snakes path
            body.transform.LookAt(point);

            index++;


           
        }
    }

    private void SnakeGrowing() {
        // Instantiate body instance and
        // add it to the list
        GameObject body = Instantiate(BodyPrefab);
        BodyParts.Add(body);
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Food"))
        {
            Destroy(other.gameObject);
            SnakeGrowing();

                // Calculate random position within spawn radius
            Vector3 spawnPosition = new Vector3(Random.Range(-spawnRadius, spawnRadius), 0.3f, Random.Range(-spawnRadius, spawnRadius));

            // Instantiate food at the random position
            Instantiate(foodPrefab, spawnPosition, Quaternion.identity);   
        }

        else if (other.CompareTag("Obstacles")) // Check for obstacle collision
        {
           SceneManager.LoadScene("GameLost");
        }
        
    }
}